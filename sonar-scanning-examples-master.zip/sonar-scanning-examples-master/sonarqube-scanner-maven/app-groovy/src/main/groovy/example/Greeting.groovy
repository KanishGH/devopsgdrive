package example

class Greeting {
  def say() {
    println 'Hello World'
  }
}
